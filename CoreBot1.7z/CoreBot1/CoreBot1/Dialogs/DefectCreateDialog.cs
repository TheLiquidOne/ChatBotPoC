﻿using CoreBot1.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Recognizers.Text;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace CoreBot1.Dialogs
{
    public class DefectCreateDialog : CancelAndHelpDialog
    {
        public DefectCreateDialog() : base(nameof(DefectCreateDialog))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new ChoicePrompt(Culture.English) { Style = ListStyle.Auto });
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                TitleStepAsync,
                BodyStepAsync,
                AssignmentStepAsync,
                ConfirmStepAsync,
                ValidationStepAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> TitleStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var defectCreation = (DefectCreation)stepContext.Options;

            if (string.IsNullOrEmpty(defectCreation.Title))
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions {
                    Prompt = MessageFactory.Text("Can you give a very short description of your problem (in 20 words please) ?")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(defectCreation.Title, cancellationToken);
            }

        }

        private async Task<DialogTurnResult> BodyStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var defectCreation = (DefectCreation)stepContext.Options;
            defectCreation.Title = (string)stepContext.Result;

            if (string.IsNullOrEmpty(defectCreation.Description))
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions {
                    Prompt = MessageFactory.Text("Can you give detailds about your problem ? (Don't forget to explain different steps you did)")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(defectCreation.Description, cancellationToken);
            }
        }
        private async Task<DialogTurnResult> AssignmentStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var defectCreation = (DefectCreation)stepContext.Options;
            defectCreation.Description = (string)stepContext.Result;

            if (string.IsNullOrEmpty(defectCreation.Fixer))
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Who should fix that issue ?")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(defectCreation.Title, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            var defectCreation = (DefectCreation)stepContext.Options;
            defectCreation.Fixer = (string)stepContext.Result;

            var msg = $"Please confirm, you want to create a defect named \"{defectCreation.Title}\" and a body as \"{defectCreation.Description}\"" +
                $"{Environment.NewLine} It should probably be fixed by {defectCreation.Fixer}";

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions {
                Prompt = MessageFactory.Text(msg)
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> ValidationStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var defectCreation = (DefectCreation)stepContext.Options;

                return await stepContext.EndDialogAsync(defectCreation, cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}
