using System.Threading;
using System.Threading.Tasks;
using CoreBot1.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CoreBot1.Dialogs
{
    public class MainDialog : ComponentDialog
    {
        protected readonly IConfiguration Configuration;
        protected readonly ILogger Logger;

        public MainDialog(IConfiguration configuration, ILogger<MainDialog> logger)
            : base(nameof(MainDialog))
        {
            Configuration = configuration;
            Logger = logger;

            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ScopeDialog());
            AddDialog(new AdminScopeDialog());
            AddDialog(new AppScopeDialog());
            AddDialog(new DefectCreateDialog());
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                IntroStepAsync,
                ActStepAsync,
                DefectCreationStepAsync,
                FinishStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> FinishStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you. Happy day !"), cancellationToken);
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }

        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions {
                Prompt = MessageFactory.Text("What can I help you with today?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            var isCreateDefect = await LuisHelper.ExecuteLuisQuery(Configuration, Logger, stepContext.Context, cancellationToken);

            if (isCreateDefect)
            {
                var defect = new DefectCreation();
                return await stepContext.BeginDialogAsync(nameof(DefectCreateDialog), defect, cancellationToken);
            }

            return await stepContext.BeginDialogAsync(nameof(ScopeDialog), new ScopeDetails(), cancellationToken);
        }

        private async Task<DialogTurnResult> DefectCreationStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Result != null)
            {
                var result = stepContext.Result;

                if (result is DefectCreation)
                {
                    // FIXME Should check that no one has already been created
                    // FIXME Should call API

                    var msg = $"We have created your defect";

                    await stepContext.Context.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
                }

                if (result is ScopeDetails)
                {
                    switch (((ScopeDetails)result).Scope)
                    {
                        case 1:
                            return await stepContext.BeginDialogAsync(nameof(AdminScopeDialog), null, cancellationToken);
                        case 2:
                            return await stepContext.BeginDialogAsync(nameof(AppScopeDialog), null, cancellationToken);
                        default:
                            break;
                    }
                }
            }
            return await stepContext.NextAsync(null, cancellationToken);
        }
    }
}
