using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;

namespace CoreBot1.Dialogs
{
    public class ScopeDialog : CancelAndHelpDialog
    {
        public ScopeDialog()
            : base(nameof(ScopeDialog))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                ScopeStepAsync,
                ChooseScopeStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> ScopeStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var ScopeDetails = (ScopeDetails)stepContext.Options;

            if (ScopeDetails.Scope == 0)
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Do you need help for admin or app ?") }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(ScopeDetails.Scope, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> ChooseScopeStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var scopeDetails = (ScopeDetails)stepContext.Options;

            switch ((string)stepContext.Result)
            {
                case "admin":
                    scopeDetails.Scope = 1;
                    break;
                case "app":
                    scopeDetails.Scope = 2;
                    break;
                default:
                    break;
            }
            return await stepContext.EndDialogAsync(scopeDetails, cancellationToken);
        }
    }
}
