﻿namespace CoreBot1.Models
{
    public class DefectCreation
    {
        public string Title { get; set; }
        public string Description { get; set; }

        public string Fixer { get; set; }
    }
}
