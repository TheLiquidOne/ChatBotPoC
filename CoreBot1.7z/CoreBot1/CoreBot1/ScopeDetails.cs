namespace CoreBot1
{
    public class ScopeDetails
    {
        public int Scope { get; set; }
    }
}
